


# DocumentDB as a source doesn't support secrets like RDS etc. do.

Once deployed, you can use the dms-secrets-role and the secret by modifying the endpoint in the console.
To redeploy changes, modify back to user/pw and remove secrets, then deploy, then modify to secrets.

Edit these in to go from Secrets in SM, to "Provide access information manually"
- Username
- Password
- Port
- Server
- Database name: Mandatory for older DMS/DocDB! Doesn't get pulled from secrets!

to

Use Secrets manager
`service/dms/docdb-staging/connection/staging`
plus IAM role for it
`dms-secrets-role`

# HACK to get by until we migrate to MongoDB.

