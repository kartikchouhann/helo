 When adding a new DocumentDB endpoint for Morpheus, the TF plan required replacement of an unrelated task.

/* cspell:disable */
 ```
     {
      endpoint_id   = "morpheus-activities"
      endpoint_type = "source"
      engine_name   = "docdb"
      ssl_mode      = "verify-full"

      database_name = "activitiesDB"

      username = "fake"
      password = "fake"
      server_name = "fake"
      port = 27017
    }
 ```

 ```
   # module.dms.aws_dms_replication_task.this["feed-rds-s3-export-full-and-cdc-sandbox"] must be replaced
-/+ resource "aws_dms_replication_task" "this" {
      + cdc_start_position        = (known after apply)
      ~ id                        = "feed-rds-s3-export-full-and-cdc-sandbox" -> (known after apply)
      ~ replication_task_arn      = "arn:aws:dms:us-west-2:512438066734:task:DJ3SQI6LMRFEPG42UUVSNQU3M4" -> (known after apply)
      ~ replication_task_settings = jsonencode(
          ~ {
              ~ ChangeProcessingTuning              = {
                  - RecoveryTimeout               = -1
                    # (10 unchanged attributes hidden)
                }
              ~ ControlTablesSettings               = {
                  - CommitPositionTableEnabled    = false
                    # (7 unchanged attributes hidden)
                }
              ~ ErrorBehavior                       = {
                  - DataMaskingErrorPolicy                      = "STOP_TASK"
                    # (22 unchanged attributes hidden)
                }
              ~ Logging                             = {
                  - CloudWatchLogGroup  = "dms-tasks-vas-replication-instance-full-and-cdc"
                  - CloudWatchLogStream = "dms-task-DJ3SQI6LMRFEPG42UUVSNQU3M4"
                    # (3 unchanged attributes hidden)
                }
                # (10 unchanged attributes hidden)
            }
        )
      ~ source_endpoint_arn       = "arn:aws:dms:us-west-2:512438066734:endpoint:BWNNKYFQEBHBLDWI6OVGJWKRLM" # forces replacement -> (known after apply) # forces replacement
      ~ status                    = "ready" -> (known after apply)
      - tags                      = {} -> null
      ~ target_endpoint_arn       = "arn:aws:dms:us-west-2:512438066734:endpoint:FR7MP6NP2RGBVGBPSZ6OJGLZVU" # forces replacement -> (known after apply) # forces replacement
        # (6 unchanged attributes hidden)
    }
 ```
 /* cspell:enable */

 The short-term workaround was to create a separate state file for managing the Morpheus DMS resources so that they do not impact existing migrations.  The DMS resources and statefile can be deleted when the engineering teams have updated their applications to use Atlas. A JIRA ticket will be created to investigate the issue and determine a long-term solution, including refactoring the DMS module.

/* cspell:disable */
 ```
   backend "s3" {
    key = "terraform/pulse/database/dms-morpheus-docdb/terraform.tfstate"
  }

 ```
 /* cspell:enable */