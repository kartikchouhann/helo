
# Warning

If you delete or disable the VPC Flow Logs, you need to wait a long time to delete the cloudwatch log groups: Perhaps 20 minutes.


# Local deployment


export AWS_PROFILE=platform-prod
export AWS_PROFILE=morpheus
export AWS_PROFILE=pulse-network
export AWS_PROFILE=pulse-network-prod
export AWS_PROFILE=pulse-backup
export AWS_PROFILE=pulse-data
export AWS_PROFILE=pulse-sandbox
export AWS_PROFILE=pulse-staging
export AWS_PROFILE=pulse-prod

rm -Rf .terraform; rm .terraform.lock.hcl

export AWS_PROFILE=pulse-sandbox;terraform init -backend-config=../../env-sandbox/sandbox.conf
export AWS_PROFILE=pulse-staging;terraform init -backend-config=../../env-staging/staging.conf
export AWS_PROFILE=pulse-prod;terraform init -backend-config=../../env-prod/prod.conf
export AWS_PROFILE=pulse-network;terraform init -backend-config=../../env-network/network.conf
export AWS_PROFILE=pulse-logs;terraform init -backend-config=../../env-logs/logs.conf
export AWS_PROFILE=pulse-logs-prod;terraform init -backend-config=../../env-logs-prod/logs-prod.conf
export AWS_PROFILE=pulse-data;terraform init -backend-config=../../env-data/data.conf
export AWS_PROFILE=morpheus;terraform init -backend-config=../../env-morpheus/morpheus.conf
export AWS_PROFILE=platform-prod;terraform init -backend-config=../../env-management/management.conf

export AWS_PROFILE=pulse-sandbox;terraform plan -var-file=sandbox.tfvars -var-file=../../env-sandbox/global.tfvars -out=sandbox.tfplan
export AWS_PROFILE=pulse-staging;terraform plan -var-file=staging.tfvars -var-file=../../env-staging/global.tfvars -out=staging.tfplan
export AWS_PROFILE=pulse-prod;terraform plan -var-file=prod.tfvars -var-file=../../env-prod/global.tfvars -out=prod.tfplan
export AWS_PROFILE=pulse-network;terraform plan -var-file=network.tfvars -var-file=../../env-network/global.tfvars -out=network.tfplan
export AWS_PROFILE=pulse-logs;terraform plan -var-file=logs.tfvars -var-file=../../env-logs/global.tfvars -out=logs.tfplan
export AWS_PROFILE=pulse-logs-prod;terraform plan -var-file=logs-prod.tfvars -var-file=../../env-logs-prod/global.tfvars -out=logs-prod.tfplan
export AWS_PROFILE=pulse-data;terraform plan -var-file=data.tfvars -var-file=../../env-data/global.tfvars -out=data.tfplan
export AWS_PROFILE=morpheus;terraform plan -var-file=morpheus.tfvars -var-file=../../env-morpheus/global.tfvars -out=morpheus.tfplan
export AWS_PROFILE=platform-prod;terraform plan -var-file=management.tfvars -var-file=../../env-management/global.tfvars -out=management.tfplan

terraform apply "network.tfplan"


# Pushing an empty state to management for a VPC to reference in route53 before falling back to a var.
This might bite us later.

export AWS_PROFILE=platform-prod;terraform state push .terraform/terraform.tfstate