
# Warning

When you change the table mappings, it will shut the DMS replication tasks down.
When you just start them back up, they don't notice the new changes.

If you update the engine version
- Shut down migration tasks
- Restarted the DMS compute
None of that worked.
Wiped s3/databricks, then re-ran DMS and the columns appeared. 
- Have to wipe out bronze, change the checkpoint path so they can ingest cleanly.


## Updating DMS version

Changing the version in the reusable module doesn't automatically deploy. It goes as a pending update. 
- Can update in console, apply immediately, and update in code
- Could add apply immediately to the code


### Initial setup

DocumentDB: https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Source.DocumentDB.html

Requires CERTIFICATE!

```
db.adminCommand({modifyChangeStreams: 1,
    database: "DB_NAME", // or database: "*",
    collection: "", 
    enable: true});
```