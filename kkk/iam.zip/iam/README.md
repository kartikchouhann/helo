# This module has differences
- This is a pre-requisite to freely deploying modules, other modules should use the kms key(s) this creates (e.g. dynamo state lock)
- Can't include the dynamo state lock in the .conf
- Needs Account & state buckets (state for their deployments stored externally in another bucket) deployed first
- Using local dir .conf and tfvars since our dependencies are minimal (global has many)
- Deployment commands don't use global tfvars
- KMS policies must allow an individual user to engage with the KMS keys in order to deploy them e.g. dynamo

# Local deployment 

The first deployment needs to be manual, since it's prior to anything existing in the new account. Then we can create the dynamodb lock, to enable CICD deployments.

Add your AWS Profile to config.tf
- Backend
- AWS Provider(s)
OR

export AWS_PROFILE=platform-prod
export AWS_PROFILE=morpheus
export AWS_PROFILE=platform-dev
export AWS_PROFILE=pulse-network
export AWS_PROFILE=pulse-network-prod
export AWS_PROFILE=pulse-backup
export AWS_PROFILE=pulse-data
export AWS_PROFILE=pulse-sandbox
export AWS_PROFILE=pulse-staging
export AWS_PROFILE=pulse-prod

rm -rf .terraform; rm .terraform.lock.hcl

export AWS_PROFILE=pulse-sandbox;terraform init -backend-config=../../env-sandbox/sandbox.conf
export AWS_PROFILE=pulse-staging;terraform init -backend-config=../../env-staging/staging.conf
export AWS_PROFILE=pulse-prod;terraform init -backend-config=../../env-prod/prod.conf
export AWS_PROFILE=pulse-network;terraform init -backend-config=../../env-network/network.conf
export AWS_PROFILE=pulse-logs;terraform init -backend-config=../../env-logs/logs.conf
export AWS_PROFILE=pulse-logs-prod;terraform init -backend-config=../../env-logs-prod/logs-prod.conf
export AWS_PROFILE=pulse-data;terraform init -backend-config=../../env-data/data.conf
export AWS_PROFILE=pulse-data-staging;terraform init -backend-config=../../env-data-staging/data-staging.conf
export AWS_PROFILE=pulse-data-prod;terraform init -backend-config=../../env-data-prod/data-prod.conf
export AWS_PROFILE=morpheus;terraform init -backend-config=../../env-morpheus/morpheus.conf
export AWS_PROFILE=platform-prod;terraform init -backend-config=../../env-management/management.conf
export AWS_PROFILE=security-audit;terraform init -backend-config=../../env-security/security.conf

export AWS_PROFILE=pulse-sandbox;terraform plan -var-file=sandbox.tfvars -var-file=../../env-sandbox/global.tfvars -out=sandbox.tfplan
export AWS_PROFILE=pulse-staging;terraform plan -var-file=staging.tfvars -var-file=../../env-staging/global.tfvars -out=staging.tfplan
export AWS_PROFILE=pulse-prod;terraform plan -var-file=prod.tfvars -var-file=../../env-prod/global.tfvars -out=prod.tfplan
export AWS_PROFILE=pulse-network;terraform plan -var-file=network.tfvars -var-file=../../env-network/global.tfvars -out=network.tfplan
export AWS_PROFILE=pulse-logs;terraform plan -var-file=logs.tfvars -var-file=../../env-logs/global.tfvars -out=logs.tfplan
export AWS_PROFILE=pulse-logs-prod;terraform plan -var-file=logs-prod.tfvars -var-file=../../env-logs-prod/global.tfvars -out=logs-prod.tfplan
export AWS_PROFILE=pulse-data;terraform plan -var-file=data.tfvars -var-file=../../env-data/global.tfvars -out=data.tfplan
export AWS_PROFILE=pulse-data-staging;terraform plan -var-file=data-staging.tfvars -var-file=../../env-data-staging/global.tfvars -out=data-staging.tfplan
export AWS_PROFILE=pulse-data-prod;terraform plan -var-file=data-prod.tfvars -var-file=../../env-data-prod/global.tfvars -out=data-prod.tfplan
export AWS_PROFILE=morpheus;terraform plan -var-file=morpheus.tfvars -var-file=../../env-morpheus/global.tfvars -out=morpheus.tfplan
export AWS_PROFILE=platform-prod;terraform plan -var-file=management.tfvars -var-file=../../env-management/global.tfvars -out=management.tfplan
export AWS_PROFILE=security-audit;terraform plan -var-file=security.tfvars -var-file=../../env-security/global.tfvars -out=security.tfplan

terraform apply "management.tfplan"

# CICD

CICD would need two tfvars

# DMS Secrets

DMS secret must be objects, and must me similar to this:

{
  "username":"placeholder",
  "password":"placeholder",
  "port":"placeholder",
  "host":"placeholder"
}